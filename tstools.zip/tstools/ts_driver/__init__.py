""" Module containing timeseries "drivers"

Timeseries "drivers' handle data requests from plugin for a specific dataset
or algorithm configuration.
"""
